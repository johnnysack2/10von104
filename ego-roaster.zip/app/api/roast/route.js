const base64Data = image.split(',')[1];
const mimeType = image.split(';')[0].split(':')[1];

const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

const prompt = `
    You are a brutal, cynical, but hilarious roast master. You are analyzing a user's Tinder profile or Instagram feed.
    Your goal is to destroy their ego but also give them helpful advice.
    
    Output a JSON object with the following keys:
    - rating: A number from 1 to 10 (be harsh).
    - roast: A short, biting paragraph roasting the user based on the image. Make it personal and specific to what you see.
    - tips: An array of 3 specific, actionable tips to improve their profile/feed.
    
    Do not hold back. Be "mean" but funny.
    Return ONLY the JSON.
    `;

const result = await model.generateContent([
    prompt,
    {
        inlineData: {
            data: base64Data,
            mimeType: mimeType
        }
    }
]);

const responseText = result.response.text();
console.log("Raw Gemini response:", responseText);

// Clean up markdown code blocks if present
let jsonString = responseText.replace(/```json\n?|```/g, "").trim();

// Attempt to find the first '{' and last '}' to extract JSON
const firstOpen = jsonString.indexOf('{');
const lastClose = jsonString.lastIndexOf('}');
if (firstOpen !== -1 && lastClose !== -1) {
    jsonString = jsonString.substring(firstOpen, lastClose + 1);
}

let data;
try {
    data = JSON.parse(jsonString);
} catch (parseError) {
    console.error("JSON Parse Error:", parseError);
    console.error("Failed JSON string:", jsonString);
    return NextResponse.json({ error: 'Failed to parse AI response', details: responseText }, { status: 500 });
}

return NextResponse.json(data);
    } catch (error) {
    console.error('Error roasting image:', error);
    return NextResponse.json({
        error: 'Failed to roast image',
        details: error.message,
        stack: error.stack
    }, { status: 500 });
}
}
